# SPDX-License-Identifier: Apache-2.0
# TFD-Bench modification: adapted for one-dimensional fault-diagnosis benchmarking.
"""One-dimensional models for fault diagnosis."""

from src.models.resnet import resnet1d, packed_resnet1d, bayesian_resnet1d, batchensemble_resnet1d
from src.models.lenet import lenet1d, packed_lenet1d, bayesian_lenet1d, batchensemble_lenet1d
from src.models.transformer import transformer1d, packed_transformer1d, bayesian_transformer1d, batchensemble_transformer1d
from src.models.mlp import mlp, packed_mlp, bayesian_mlp
from src.models.timesnet import Model as timesnet1d


__all__ = [
    "resnet1d", "packed_resnet1d", "bayesian_resnet1d", "batchensemble_resnet1d",
    "lenet1d", "packed_lenet1d", "bayesian_lenet1d", "batchensemble_lenet1d",
    "transformer1d", "packed_transformer1d", "bayesian_transformer1d", "batchensemble_transformer1d",
    "mlp", "packed_mlp", "bayesian_mlp", "timesnet1d",
]
